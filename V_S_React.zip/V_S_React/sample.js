const http = require('http');  
const PORT = 6100;

const server = http.createServer((request, response) => {
   // Set the response header to indicate HTML content type
   response.writeHead(200, { 'Content-Type': 'text/plain' });

   // Node.js program to print numbers from 1 to 100 with conditions
   for (let i = 1; i <= 100; i++) {
       if (i % 3 === 0 && i % 5 === 0) {
           response.write('foobar\n'); // Add newline after each output
       } else if (i % 3 === 0) {
           response.write('foo\n');
       } else if (i % 5 === 0) {
           response.write('bar\n');
       } else {
           response.write(i + '\n'); // Add newline after each number
       }
   }

   response.end();  // End the response
});

server.listen(PORT, () => {
    console.log(`SERVER IS LISTENING ON PORT ${PORT}`);
});
