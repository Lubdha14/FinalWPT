const apiUrl = 'https://saurav.tech/NewsAPI/top-headlines/category/health/in.json';

async function fetchNews() {
    try {
        const response = await fetch(apiUrl);
        const data = await response.json();
        const container = document.getElementById('news-container');
        container.innerHTML = data.articles?.map(article => 
            `<div class="news-item">
                <h2><a href="${article.url}" target="_blank">${article.title}</a></h2>
                <p>${article.description || 'No description available.'}</p>
                <p><strong>Source:</strong> ${article.source.name}</p>
            </div>`).join('') || '<p>No news available.</p>';
    } catch {
        document.getElementById('news-container').innerHTML = '<p>Error loading news.</p>';
    }
}

window.onload = fetchNews;
